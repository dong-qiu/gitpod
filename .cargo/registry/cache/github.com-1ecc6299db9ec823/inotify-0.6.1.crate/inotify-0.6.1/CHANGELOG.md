<a name="v0.6.1"></a>
### v0.6.1 (2018-08-28)


#### Bug Fixes

*   Don't return spurious filenames ([2f37560f](2f37560f))



<a name="v0.6.0"></a>
## v0.6.0 (2018-08-16)


#### Features

*   Handle closing of inotify instance better ([824160fe](824160fe))
*   Implement `EventStream` using `mio` ([ba4cb8c7](ba4cb8c7))



<a name="v0.5.1"></a>
### v0.5.1 (2018-02-27)

#### Features

*   Add future-based async API ([569e65a7](569e65a7), closes [#49](49))



