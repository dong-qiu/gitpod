import time

while True:
    print "hi"
    time.sleep(1)
