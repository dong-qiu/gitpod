## 2.0.5 (18 Jun 2018)

* update `lazycell` from 0.6 -> 1.0

## 2.0.4 (7 Apr 2018)

* Bump mio dependency (fixes minimal-versions build)

## 2.0.3 (28 Dec 2017)

* update `log` from 0.3 -> 0.4

## 2.0.2

* More docs tidying.

## 2.0.1

* Another try at documenting the timer interface.

## 2.0.0

* Remove channel implementation details from the API.  Specifically, the following are no longer public:
  * `ctl_pair()`
  * `SenderCtl`
  * `ReceiverCtl`
* Document all APIs

## 1.0.0

* Initial release.  Essentially identical to [mio-more](https://github.com/carllerche/mio-more).
