<a name="v0.1.3"></a>
### v0.1.3 (2018-07-26)


#### Bug Fixes

*   Use platform-specific constants from libc ([b363dff1](b363dff1))
